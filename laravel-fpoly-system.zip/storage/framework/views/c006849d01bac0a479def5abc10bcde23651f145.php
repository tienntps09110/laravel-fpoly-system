
<h4 class="alert-success-neo m-4 p-2 text-center">Tạo giáo viên</h4> 
<form method="POST" action="<?php echo e(route('create-teachers-excel')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group col-lg-8 mx-auto">
        <label for="excelTeachers">Excel File</label>
        <input id="excelTeachers" class="form-control" type="file" name="excelTeachers">
    </div>
    
    <div class="form-group col-lg-8 mx-auto text-right">
        <button id="BtcreateTeachers" class="btn btn-primary-neo" type="button">Lưu</button>
    </div>
</form>

<script>
    $('#BtcreateTeachers').click( () => {
        let  _tokenTeacher = '<?php echo e(csrf_token()); ?>';
        let excel        = $("#excelTeachers");
        let messSuccess = $("#resultAjaxSuccess");
        let messError   = $("#resultAjaxError");
        let formData = new FormData();
        // console.log(excel[0].value);
        formData.append('excel', excel[0].files[0]);
        // console.log(formData.get('excel'));
        $.ajax({
            type:'POST',
            data: formData,
            url:'<?php echo e(route('create-teachers-excel')); ?>',
            contentType: false,
            processData: false,
            headers: {
                'X-CSRF-TOKEN': _tokenTeacher,
            },
            success:function(data) {
                if(data.Status == 200){
                    // messSuccess.html(data.Message).removeClass('d-none');
                    // setTimeout( () => { messSuccess.addClass('d-none').html('')  }, 5000);
                    // console.log(data);
                    toastMess (data.Message, 5000,'success');
                }else{
                    // messError.removeClass('d-none');
                    if(typeof data.Message == 'object'){
                        $.each(data.Message, function(key, value){
                            // messError.append(this + '<br>');
                            toastMess (this, 5000,'error');
                        });
                    }else{
                        // messError.html(data.Message);
                        toastMess (data.Message, 5000,'error');
                    }
                    // setTimeout( () => { messError.addClass('d-none').html('')  }, 5000);
                    // console.log(data);
                }
            },
            error: function(data) {
                console.log(data);
            }
        });
    });
</script><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/create-teachers.blade.php ENDPATH**/ ?>