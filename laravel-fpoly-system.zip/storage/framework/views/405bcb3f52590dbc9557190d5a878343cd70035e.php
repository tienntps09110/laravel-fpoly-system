
<?php $__env->startSection('contentAdmin'); ?>
    <form action="<?php echo e(route('logout')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <button type="submit" class="text-center">(<?php echo e(Auth::user()->full_name); ?>) LOGOUT</button>
    </form>
    <h1 class="text-center text-sucess">HOME ADMIN</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/admin/1.blade.php ENDPATH**/ ?>