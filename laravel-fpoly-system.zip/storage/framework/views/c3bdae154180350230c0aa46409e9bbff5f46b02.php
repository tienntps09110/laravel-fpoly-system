<nav id="sidebar">
    <div class="fixed-sidebar">
        <div class="sidebar-header">
            <div class="rounded-circle">
                <img src="<?php echo e(Auth::user()->avatar_img_path); ?>" alt="<?php echo e(Auth::user()->avatar_img_path); ?>" width="100%" >
            </div>        
        </div>
    
        <ul class="list-unstyled components">
            <p class="text-center" style="background-color: #1EBD9E;"><?php echo e(Auth::user()->full_name); ?></p>
            <li>
                <a href="<?php echo e(route('department-home')); ?>">Nhập thông tin <span style="float: left;"><i class="fas fa-user-plus"></i></span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('create-class-subject-view')); ?>">Phân lớp <span style="float: left;"><i class="fas fa-divide"></i></span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('create-user-view')); ?>">Tạo thành viên <span style="float: left;"><i class="fas fa-divide"></i></span>
                </a>
            </li>
            <li> <a> <i class="fas fa-list"></i> Danh sách</a> 
                <ul>
                    <li>
                        <a href="<?php echo e(route('get-class-subjects')); ?>">DS Tổng hợp<span style="float: left;"><i class="fas fa-list"></i></span> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('get-users')); ?>">DS thành viên<span style="float: left;"><i class="fas fa-list"></i></span> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('get-students')); ?>"> DS Sinh viên<span style="float: left;"><i class="fas fa-list"></i></span> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('get-class')); ?>">  DS Lớp học <span style="float: left;"><i class="fas fa-list"></i></span> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('get-subjects')); ?>"> DS Môn học<span style="float: left;"><i class="fas fa-list"></i></span> </a>
                    </li>
                </ul>
                
            </li>
            
        </ul>
    
        <ul class="list-unstyled CTAs">
            <li>
                <form action="<?php echo e(route('logout')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-link logout"> <i class="fas fa-sign-out-alt"></i> Đăng xuất  </button> 
                </form>
            </li>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>