<div class="table-responsive">
    <table class="stripe " id="datatable" >
        <thead class="">
        <tr>
            <th scope="col">#</th>
            <th scope="col">Mã số</th>
            <th scope="col" class="row-width-200">Họ và tên</th>
            <th scope="col">Giới tính</th>
            <th scope="col">Lớp</th>
            
            <th scope="col">Số điện thoại</th>
            <th scope="col">Email</th>
            <th scope="col">Hình ảnh</th>
            <th scope="col"></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($student->student_code); ?></td>
                <td class="row-width-200"><?php echo e($student->full_name); ?></td>
                <td ><?php echo e($student->sex); ?></td>
                <td><?php echo e($student->class->name); ?></td>
                
                <td><?php echo e($student->phone_number); ?></td>
                <td><?php echo e($student->email); ?></td>
                <td class="text-center">
                    <img src="<?php echo e($student->avatar_img_path); ?>" alt="<?php echo e($student->avatar_img_path); ?>" height="100px">
                </td>
                <td>
                    <button class="button-update-student btn btn-link" type="button" data="<?php echo e(route('update-student', $student->id)); ?>">Cập nhật</button>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<script>
$(document).ready(()=>{
    var buttonUpdate = $('.button-update-student');
    buttonUpdate.each(function(){
        $(this).click(function(){
        // console.log($(this).attr('data'))
        $('#view-modal-update').html('<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>')
        .attr('style', 'position: fixed; top: 50%; z-index: 2; left: 50%;');
        $.ajax({
            type: 'GET',
            url: $(this).attr('data'),
            success(data){
            // console.log(data)
            $('#view-modal-update').html('').attr('style', '')
            $('#view-modal-update').html(data)
            }
        })
        })
    })
})
</script>

<script src="<?php echo e(asset('/js/script.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/com-students.blade.php ENDPATH**/ ?>