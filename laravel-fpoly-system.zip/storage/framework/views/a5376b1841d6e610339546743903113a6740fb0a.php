
<?php $__env->startSection('content-teacher'); ?>

<div class="container-fluid p-4">
  <div class="content box p-lg-5 p-3 ">
      <div class="text-center mb-lg-3 p-2 alert-primary-neo title">
          Danh sách lớp dạy
      </div>
      <div class="table-responsive">
          <table class="table ">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Lớp</th>
              <th scope="col" class="row-width-200">Môn</th>
              <th scope="col">Thời gian</th>
              <th scope="col" class="row-width-300">Ca học</th>
              <th scope="col" class="row-width-200" style="width: 300px;">Thứ học</th>
              <th scope="col"> </th>
            </tr>
          <?php $__currentLoopData = $classSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detailCs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"> <?php echo e(++$key); ?> </th>
              <td > <?php echo e($detailCs->class_name); ?> </td>
              <td ><?php echo e($detailCs->subject_name); ?></td>
              <td><?php echo e($detailCs->study_time_name); ?></td>
              <td > <?php echo e($Carbon::parse($detailCs->datetime_start)->format('d/m/Y') .' - ' .$Carbon::parse($detailCs->datetime_end)->format('d/m/Y')); ?> </td>
              <td >
                <?php for($i = 0; $i < count(json_decode($detailCs->days_week)); $i++): ?>
                  <span class="badge badge-pill badge-primary badge-primary-neo" style=""><?php echo e($Core::dayString(json_decode($detailCs->days_week)[$i])); ?></span>  
                <?php endfor; ?>
              </td>
              <td>
                  <a class="btn btn-primary-neo" href="<?php echo e(route('get-class-subject-teacher', $detailCs->id)); ?>">Thông tin</a>        
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
      </div>
  </div>
</div>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/teacher/get-class-subjects.blade.php ENDPATH**/ ?>