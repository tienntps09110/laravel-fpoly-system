
<?php $__env->startSection('content-student'); ?>


<div class="container-fluid  p-4">
    <div class="box p-4">
        <div class="title p-lg-4 font-weight-bold">
            Chi tiết Môn: <span class="display-4 font-weight-bold ml-lg-4" id="ten-mon"><?php echo e($classSubject->subject_name); ?> </span>
            <a href="<?php echo e(route('get-class-subjects-student')); ?>" id='backward'><i class="fas fa-sign-out-alt    "></i></a>
        </div>
        <div class="row py-3 mt-2 ">
            
            <div class="col-lg-3 p-lg-3 p-1 text-center ">Ngày bắt đầu:</div>
            <div class="col-lg-3 p-lg-3 p-1 text-center font-weight-bold "><?php echo e($Carbon::parse($classSubject->datetime_start)->format('d/m/Y')); ?></div>
            <div class="col-lg-3 p-lg-3 p-1 text-center">Ngày kết thúc:</div>
            <div class="col-lg-3 p-lg-3 p-1 text-center font-weight-bold"> <?php echo e($Carbon::parse($classSubject->datetime_end)->format('d/m/Y')); ?></div>
            <div class="col-lg-3 p-lg-3 p-1 text-center">Giáo viên phụ trách:</div>
            <div class="col-lg-3 p-lg-3 p-1 text-center font-weight-bold"><?php echo e($classSubject->user_full_name); ?></div>
            <div class="col-lg-3 p-lg-3 p-1 text-center">Lớp học:</div>
            <div class="col-lg-3 p-lg-3 p-1 text-center font-weight-bold"><?php echo e($classSubject->class_name); ?></div>
            <div class="col-lg-3 p-lg-3 p-1 text-center">Số ngày nghỉ tối đa:</div>
            <div class="col-lg-3 p-lg-3 p-1 text-center font-weight-bold"><?php echo e($classSubject->subject_days_fail); ?> ngày</div>
            <div class="col-lg-3 p-lg-3 p-1 text-center">Số ngày nghỉ hiện tại:</div>
            <div class="col-lg-3 p-lg-3 p-1 text-center font-weight-bold"><?php echo e($countdayStudy); ?> ngày</div>
        </div>

        <div class="px-lg-5">
            <div class="table-responsive">
                <table class="stripe " id="datatable">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Ngày học</th>
                            <th class="row-width-300">Ca học</th>
                            <th class="row-width-200"> Giảng viên</th>
                            <th> </th>
                            
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daysClassSubject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $daysDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <tr>
                                
                                <td><?php echo e(++$key); ?></td>
        
                                
                                <td><?php echo e($Carbon::parse($daysDetail->date)->format('d/m/Y')); ?> (<?php echo e($Core::dayString(json_decode( $Carbon::parse($daysDetail->date)->dayOfWeek))); ?>)</td>
        
                                
                                <td><?php echo e($classSubject->study_time_name); ?> - <?php echo e($classSubject->study_time_start); ?> đến <?php echo e($classSubject->study_time_end); ?></td>
        
                                
                                <td><?php echo e($daysDetail->user_full_name); ?></td>
        
                                
                                <td class="<?php echo e($daysDetail->checked =="false" ? "text-danger" :" text-success "); ?>" > <?php echo e($daysDetail->checked =="false" ? "Chưa Dạy" :"Đã dạy"); ?> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('student.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/student/get-class-subject.blade.php ENDPATH**/ ?>