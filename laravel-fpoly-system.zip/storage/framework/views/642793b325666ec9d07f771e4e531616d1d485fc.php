
<?php $__env->startSection('content-teacher'); ?>
<div class="container-fluid p-lg-5 p-3">
    <div class="nut-up">
        <i class="fas fa-chevron-circle-up    "></i>
    </div>
    <div class="box p-lg-5 p-3 ">
        <div class="text-center alert-primary-neo title p-2 mb-lg-3">ĐIỂM DANH </div>
        
        <div>
            <?php if($errors->any()): ?>
                <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
        
        <?php if(session('Danger')): ?>
            <div class="alert alert-danger-neo font-weight-bold text-center">
                <?php echo e(session('Danger')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('Success')): ?>
            <div class="alert alert-success-neo font-weight-bold text-center">
                <?php echo e(session('Success')); ?>

            </div>
        <?php endif; ?>
        
        <div class="table-responsive"  >
             <table class="table text-center" >
            <thead>
                <tr>
                    <th>#</th>
                    <th>Mã sinh viên</th>
                    <th class="row-width-200">Họ và Tên</th>
                    <th  >Hình</th>
                    <th  >
                        <button class="" id="kiem-tra-vang">Vắng</button>
                        <button class="btn btn-primary-neo" id="kiem-tra-tong">Tổng</button>
                    </th>
                </tr>
            </thead>
            <tbody>
                <form method="post" action="<?php echo e(route('attendance-students-post')); ?>">
                    <?php echo csrf_field(); ?>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="row-center">
                            <td ><?php echo e(++$key); ?> </td>
                            <td> <?php echo e($student->student_code); ?> </td>
                            <td> <?php echo e($student->full_name); ?> </td>
                            <th >
                                <img src="<?php echo e($student->avatar_img_path); ?>" alt="<?php echo e($student->avatar_img_path); ?>"  width="100px">
                            </th>
                            <td  >
                                <div class="confirm-switch mx-auto">
                                    <input type="checkbox" id="default-switch<?php echo e($student->id); ?>" value="<?php echo e($student->id); ?>" name="attendance[]">
                                    <label for="default-switch<?php echo e($student->id); ?>"></label>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                    <input type="hidden" name="days_class_subject_id" value="<?php echo e($classSubject->dcs_id); ?>">
                    <input type="hidden" name="class_id" value="<?php echo e($classSubject->class_id); ?>">
                    <input type="hidden" name="study_time_id" value="<?php echo e($classSubject->study_time_id); ?>">
                    <tr class=" ">
                        <td colspan="4"  class="text-secondary font-italic small">  
                            <textarea type="text" class="form-control" name="note" placeholder="Ghi chú..."></textarea>
                        </td>
                        <td  >
                            <button type="submit" class=" " id="luu" <?php echo e($timeOut=='false'?'':'disabled'); ?>>Lưu lại</button>
                            <div id="loading"></div>
                        </td>
                    </tr>
                </form>
            </tbody>
        </table>
        </div>
    </div>
    
</div>
<script>
    $(document).ready(()=>{
        $('#luu').click(()=>{
            $('#luu').hide();
            $('#loading').html('<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>')
        })
    })
</script>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('teacher.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/teacher/get-attendance-today.blade.php ENDPATH**/ ?>