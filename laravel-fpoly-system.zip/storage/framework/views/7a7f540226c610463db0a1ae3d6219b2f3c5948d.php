
<?php $__env->startSection('contentPDT'); ?>

<div class="container-fluid  p-4">
    <div class="box p-4">
        <div class="title p-2 mb-3  text-center alert-primary-neo">
            Danh sách Lớp học Toàn trường
           
        </div>
         
        <div class="p-lg-4">
            <div class="table-responsive">
                <table class="stripe " id="table_all_classes" >
                  <thead class="">
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Lớp học</th>
                      <th scope="col" class="row-width-200">Môn học</th>
                      <th scope="col">Giáo viên phụ trách</th>
                      <th scope="col" class="row-width-200">Thứ học</th>
                      <th scope="col">Ca học</th>
                      <th scope="col">Ngày bắt đầu</th>
                      <th scope="col">ngày kết thúc</th>
                      <th scope="col"></th>
                    </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $classSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $classSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($classSubject->class_name); ?></td>
                                <td  class="row-width-200"><?php echo e($classSubject->subject_name); ?></td>
                                <td><?php echo e($classSubject->user_name); ?></td>
                                <td class="row-width-200">
                                    <?php for($i = 0; $i < count(json_decode($classSubject->days_week)); $i++): ?>
                                        <span class="badge badge-pill badge-primary badge-primary-neo" style=""><?php echo e($Core::dayString(json_decode($classSubject->days_week)[$i])); ?></span>  
                                    <?php endfor; ?>   
                                </td>
                                <td><?php echo e($classSubject->study_time_name); ?></td>
                                <td><?php echo e($classSubject->study_time_start); ?></td>
                                <td><?php echo e($classSubject->study_time_end); ?></td>
                                <td>
                                    <a class="btn btn-link" href="<?php echo e(route('get-class-subject', $classSubject->id)); ?>">Chi tiết</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <script>
                            $(document).ready(function(){
                                $('#table_all_classes').DataTable({
                                    language:{
                                        sProcessing: 'Đang xử lý...',
                                        sLengthMenu: 'Xem _MENU_ mục',
                                        sZeroRecords: 'Không tìm thấy dòng nào phù hợp',
                                        sInfo: 'Đang xem <b> _START_ </b> đến <b> _END_ </b> trong tổng số <b> _TOTAL_ </b> mục',
                                        sInfoEmpty: 'Đang xem 0 đến 0 trong tổng số 0 mục',
                                        sInfoFiltered: '(được lọc từ _MAX_ mục)',
                                        sInfoPostFix: '',
                                        sSearch: 'Tìm:',
                                        sUrl: '',
                                        oPaginate: {
                                            sFirst: 'Đầu',
                                            sPrevious: 'Trước',
                                            sNext: 'Tiếp',
                                            sLast: 'Cuối'
                                        }
                                    }
                                });
                                $('#table_all_classes_filter').find('input').addClass('table-input-search');
                                $("select[name='table_all_classes_length']").addClass('length-select');
                            })
                        </script>
                  </tbody>
                </table>
              </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('department.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/get-class-subjects.blade.php ENDPATH**/ ?>