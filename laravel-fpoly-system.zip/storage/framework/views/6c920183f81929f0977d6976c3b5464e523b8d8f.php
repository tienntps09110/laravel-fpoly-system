
<?php $__env->startSection('contentPDT'); ?>

 

<div class="container-fluid  p-4">
    <div class="box p-4">
        <div class="title p-2 mb-3 text-center alert-primary-neo">
            Danh sách Giảng viên Toàn trường
        </div>
         
        <div class="p-lg-4">
            <div class="table-responsive">
                <table class="stripe text-center" id="table_all_users" >
                  <thead class="">
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Họ và tên</th>
                      <th scope="col">Chức vụ</th>
                      <th scope="col">Số điện thoại</th>
                      <th scope="col">Email</th>
                      <th scope="col">Hình ảnh</th>
                      <th scope="col"> </th>
                      
                    </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($user->full_name); ?></td>
                                <td><?php echo e($user->role->name); ?></td>
                                <td><?php echo e($user->phone_number); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <img src="<?php echo e($user->avatar_img_path); ?>" alt="<?php echo e($user->avatar_img_path); ?>" height="100px">
                                </td>
                                <td>
                                    <a href="<?php echo e(route('update-user-view', $user->uuid)); ?>" class="btn btn-link">Cập nhật</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        <script>
                            $(document).ready(function(){
                                $('#table_all_users').DataTable({
                                    language:{
                                        sProcessing: 'Đang xử lý...',
                                        sLengthMenu: 'Xem _MENU_ mục',
                                        sZeroRecords: 'Không tìm thấy dòng nào phù hợp',
                                        sInfo: 'Đang xem <b> _START_ </b> đến <b> _END_ </b> trong tổng số <b> _TOTAL_ </b> mục',
                                        sInfoEmpty: 'Đang xem 0 đến 0 trong tổng số 0 mục',
                                        sInfoFiltered: '(được lọc từ _MAX_ mục)',
                                        sInfoPostFix: '',
                                        sSearch: 'Tìm:',
                                        sUrl: '',
                                        oPaginate: {
                                            sFirst: 'Đầu',
                                            sPrevious: 'Trước',
                                            sNext: 'Tiếp',
                                            sLast: 'Cuối'
                                        }
                                    }
                                });
                                $('#table_all_users_filter').find('input').addClass('table-input-search');
                                $("select[name='table_all_users_length']").addClass('length-select');
                            })
                        </script>
                      
                  </tbody>
                </table>
              </div>
        </div>
    </div>
  </div>

 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('department.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/users.blade.php ENDPATH**/ ?>