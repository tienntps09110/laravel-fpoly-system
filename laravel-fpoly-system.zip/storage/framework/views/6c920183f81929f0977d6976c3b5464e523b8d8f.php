
<?php $__env->startSection(CheckRole::role()->code == 'admin' ? 'contentAdmin' : 'contentPDT'); ?>

 

<div class="container-fluid  p-4">
    <div class="box p-4">
        <div class="title p-2 mb-3 text-center alert-primary-neo">
            Danh sách Giảng viên Toàn trường
        </div>
         
        <div class="p-lg-4" id="load-com-users">
            
        </div>
        <div id="view-modal-update"></div>
    </div>
  </div>
<script>
    $(document).ready(function(){
        $('#load-com-users').html('')
        $.ajax({
            type: 'GET',
            url: '<?php echo e(route('com-users')); ?>',
            success(data){
                $('#load-com-users').html(data)
            }
        })
    })
</script>
 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make(CheckRole::role()->code == 'admin' ? 'admin.home' : 'department.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/users.blade.php ENDPATH**/ ?>