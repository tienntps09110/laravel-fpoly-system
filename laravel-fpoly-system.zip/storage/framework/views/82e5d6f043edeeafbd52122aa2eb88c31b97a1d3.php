
  
  <?php $__env->startSection('content.collaboration'); ?>
  <div class="container-fluid">
  <div class="container">
      <div class="row">
          <div class="col-sm-4 p-3 card-alert">
              <div class="box border d-flex flex-wrap align-content-center justify-content-center">
                  <div class="text-center">
                      Giáo viên <i class="fas fa-chalkboard-teacher    "></i>
                      </br>
                      <p id="chu-noi">5000</p>
                  </div>
              </div>
          </div>
          <div class="col-sm-4 p-3">
              <div class="box border d-flex flex-wrap align-content-center justify-content-center">
                  <div class="text-center">
                      Giáo viên <i class="fas fa-chalkboard-teacher    "></i>
                      </br>
                      <p id="chu-noi">5000</p>
                  </div>
              </div>
          </div>
          <div class="col-sm-4 p-3">
              <div class="box border d-flex flex-wrap align-content-center justify-content-center">
                  <div class="text-center">
                      Giáo viên <i class="fas fa-chalkboard-teacher    "></i>
                      </br>
                      <p id="chu-noi">5000</p>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>
<!-- hàng 2 - Biểu đồ theo tháng -->
<div class="container-fluid   p-3">
  <div class="container  ">
      <div class="box-bieu-do">
          <h5>Biểu đồ điểm danh theo tháng</h5>
          <div class=" col-lg bieu-do">
              <div class="card">
                  <div class="card-body">
                      <canvas id="myChart" width="400" height="150"></canvas>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>
<!-- hàng 3 - nhận xét GV  & Biểu đồ hình tròn điểm danh theo lớp -->
<div class="container-fluid   p-3">
  <div class="container">
      <div class="row">
          <!-- nhận xét GV -->
          <div class="col-12 p-3">
              <div class="nhan-xet">
                  <h5>Nhận xét giáo viên</h5>
                  <div class="table-responsive">
                      <table class="table">
                          <thead>
                              <tr>
                                  <th  class="th-lg">Giáo viên</th>
                                  <th class="th-lg" >Lớp</th>
                                  <th class="th-lg" >Môn</th>
                                  <th class="th-lg">Nhận xé 1t</th>
                              </tr>

                          </thead>
                          
                          <tbody>
                              <?php $__currentLoopData = $noteTeacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td scope="row"><?php echo e($item->teacher_full_name); ?></td>
                                <td> <?php echo e($item->class_name); ?></td>
                                <td><?php echo e($item->subject_name); ?></td>
                                <td> <?php echo e($item->note); ?> </td>
                            </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </tbody>
                      </table>

                  </div>
              </div>
          </div>
          <!-- Biểu đồ hình tròn điểm danh theo lớp -->
          <div class="col-lg-6 p-3">
              <div class="diem-danh-lop">
                  <h5>Biểu đồ sinh viên vắng của môn học</h5>
                  <div>
                      <div class="card-body">
                          <canvas id="myChartRadian" width="500" height=""></canvas>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>
    
<script>
    let dataRes = <?php echo json_encode($countMonth); ?>;
    let dataRadianRes = <?php echo json_encode($countClass); ?>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('collaboration.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/tien/68E2866CE2863DF6/xampp/htdocs/laravel-fpoly-system/resources/views/collaboration/full-dashboard.blade.php ENDPATH**/ ?>