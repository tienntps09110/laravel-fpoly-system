

<?php $__env->startSection(CheckRole::role()->code == 'admin' ? 'contentAdmin' : 'contentPDT'); ?>
    <div>
        <?php if($errors->any()): ?>
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
    <div>
        <?php echo e(session('Danger')?session('Danger'):''); ?>

    </div>
    <div>
        <?php echo e(session('Success')?session('Success'):''); ?>

    </div>
    
    <div class="container-fluid">
        <div class="p-3 row">
            <div class="col-lg-6 p-lg-3 py-2 ">
                <div class="box  py-2 daotao-create ">
                    <?php echo $__env->make('department.create-class', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-6 p-lg-3 py-2 ">
                <div class="box  py-2 daotao-create">
                <?php echo $__env->make('department.create-subject', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-6 p-lg-3 py-2 ">
                <div class="box  py-2 daotao-create">
                    <?php echo $__env->make('department.create-students', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="col-lg-6 p-lg-3 py-2 ">
                <div class="box py-2  daotao-create">
                    <?php echo $__env->make('department.create-teachers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make(CheckRole::role()->code == 'admin' ? 'admin.home' : 'department.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/create-all.blade.php ENDPATH**/ ?>