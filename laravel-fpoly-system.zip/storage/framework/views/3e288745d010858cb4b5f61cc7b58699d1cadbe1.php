<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-bg">
    <div class="container-fluid">
        <div class="col-lg-3 text-h2-navbar my-2 text-center" style="color: #FFFFFF;"><h3>Phòng Đào Tạo</h3></div>
        <div class="col-lg-7">
            <div>
                <form class="form-inline form-search my-2 my-lg-0 mr-5">
                    <span class="icone"> <i class="fas fa-search"></i></span>
                    <input class="form-control col-lg-6 ml-auto input-search" type="search" placeholder="Search..." aria-label="Search">
                  </form>
            </div>
        </div>
        <div class="col-lg-2">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link "style="color:#FFFFFF" href="#"><i class="fas fa-bell"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="color:#FFFFFF" href="#"><i class="fas fa-envelope"></i></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#"><i class="fas fa-bars"></i></a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- <button type="button" id="sidebarCollapse" class="btn btn-info">
            <i class="fas fa-align-left"></i>
            <span>Toggle Sidebar</span> -->
        </button>

    </div>
</nav>
<?php /**PATH /media/tien/68E2866CE2863DF6/xampp/htdocs/laravel-fpoly-system/resources/views/collaboration/navbar.blade.php ENDPATH**/ ?>