DETAIL CLASS
<br>
<hr>
<?php echo e($class); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/get-class-detail.blade.php ENDPATH**/ ?>