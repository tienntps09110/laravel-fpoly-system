<div>FORM CREATE USER</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<div>
    <?php echo e(session('Danger')?session('Danger'):''); ?>

</div>


<div>
    <?php echo e(session('Success')?session('Success'):''); ?>

</div>

<form method="POST" action="">
    <?php echo csrf_field(); ?>
    User name<input type="text" name="user_name">
    <br>
    Password<input type="password" name="password">
    <br>
    Role<select name="role">
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <br>
    full_name<input type="text" name="full_name">
    <br>
    phone_number<input type="text" name="phone_number">
    <br>
    email<input type="text" name="email">
    <br>
    avatar_img_path<input type="text" name="avatar_img_path">

    <br>
    <button type="submit">Submit</button>
</form><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/admin/create-user.blade.php ENDPATH**/ ?>