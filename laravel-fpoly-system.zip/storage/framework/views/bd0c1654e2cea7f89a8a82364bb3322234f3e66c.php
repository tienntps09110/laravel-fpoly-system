DETAIL STUDENTS

<?php echo e($student); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/get-student.blade.php ENDPATH**/ ?>