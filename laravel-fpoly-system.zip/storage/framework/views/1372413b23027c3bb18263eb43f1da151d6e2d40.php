
<?php $__env->startSection('contentPDT'); ?>
 

<div class="container-fluid  p-4">
    <div class="box p-4">
        <div class="title p-2 mb-3  text-center alert-primary-neo">
            Danh sách Sinh viên Toàn trường
        </div>
        <div class="p-lg-4">
            <div class="table-responsive">
                <table class="stripe " id="datatable" >
                  <thead class="">
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Mã số</th>
                      <th scope="col" class="row-width-200">Họ và tên</th>
                      <th scope="col">Giới tính</th>
                      <th scope="col">Lớp</th>
                      
                      <th scope="col">Số điện thoại</th>
                      <th scope="col">Email</th>
                      <th scope="col">Hình ảnh</th>
                      <th scope="col"></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($student->student_code); ?></td>
                            <td class="row-width-200"><?php echo e($student->full_name); ?></td>
                            <td ><?php echo e($student->sex); ?></td>
                            <td><?php echo e($student->class->name); ?></td>
                            
                            <td><?php echo e($student->phone_number); ?></td>
                            <td><?php echo e($student->email); ?></td>
                            <td class="text-center">
                                <img src="<?php echo e($student->avatar_img_path); ?>" alt="<?php echo e($student->avatar_img_path); ?>" height="100px">
                            </td>
                            <td>
                                <a href="<?php echo e(route('update-student', $student->id)); ?>" class="btn btn-link">Cập nhật</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
        </div>
    </div>
  </div>

  

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('department.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/get-students.blade.php ENDPATH**/ ?>