
<?php $__env->startSection(CheckRole::role()->code == 'admin' ? 'contentAdmin' : 'contentPDT'); ?>
 

<div class="container-fluid  p-4">
    <div class="box p-4">
        <div class="title p-2 mb-3  text-center alert-primary-neo">
            Danh sách Sinh viên Toàn trường
        </div>
        <div class="p-lg-4">
            <div id="load-students"></div>
            <div id="view-modal-update"></div>
        </div>
    </div>
  </div>

<script>
  $(document).ready(function(){
    $('#load-students').html('<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>')
        .attr('style', 'position: fixed; top: 50%; z-index: 2; left: 50%;');
    $.ajax({
      type: 'GET',
      url: '<?php echo e(route('com-students')); ?>',
      success(data){
        $('#load-students').html('').attr('style', '')
        $('#load-students').html(data)
      }
    })
  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make(CheckRole::role()->code == 'admin' ? 'admin.home' : 'department.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/get-students.blade.php ENDPATH**/ ?>