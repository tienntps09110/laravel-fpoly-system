
  
  <?php $__env->startSection('content.collaboration'); ?>
<!-- hàng 1 - các Nút tổng số lượng  -->
<div class="container-fluid px-lg-5  my-lg-3 ">
    <div class=" ">
        <div class="row" id="render-count-all"></div>
    </div>
</div>
<!-- hàng 2 - Biểu đồ theo tháng & Biểu đồ hình tròn điểm danh theo lớp -->
<div class="container-fluid px-lg-5 my-lg-3 ">
    <div class=" ">
        <div class="row">
            <div  class="col-lg-8 d-flex flex-column justify-content-around ">
 
                    <div id="component-dashboard-month" class=" mb-3 "></div>
                    <div id="dashboard-radius" class="mb-lg-0 mb-3 "></div>
     
            </div>
            <div class="col-lg-4 ">
                <div class="myChart" style="height:100%">
                    <div id="dashboard-news" class="" > 
                        <div class="text-center alert-primary-neo my-3 p-2">Thông tin </div>
                        <div style="">
                            <div class="ml-3">  Thông tin học tập
                                <div class="ml-5 p-2"><a href="" class=" btn-link">  [CS1]_DANH SÁCH THI LẠI CÁC MÔN ONLINE TUẦN 15.06 - 20.06 (DỰ KIẾN) </a> </div>
                                <div class="ml-5 p-2"><a href="" class="  btn-link"> 2020_SPRING_KIỂM TRA THÔNG TIN SINH VIÊN  </a> </div>
                                <div class="ml-5 p-2"><a href="" class="  btn-link">  Xem thêm ...  </a> </div>
                            </div>
                            <div class="ml-3">Thông tin hoạt động
                                <div class="ml-5 p-2"><a href="" class="  btn-link">  THÔNG BÁO DANH SÁCH SINH VIÊN THÔI HỌC CHÍNH THỨC HỌC KỲ SUMMER 2020 </a> </div>
                                <div class="ml-5 p-2"><a href="" class="  btn-link"> THÔNG BÁO PHÁT SÁCH HỌC KỲ SUMMER 2020_ĐỢT 1</a> </div>
                                <div class="ml-5 p-2"><a href="" class="  btn-link"> Xem thêm ... </a> </div>
                            </div>
                            <div class="ml-3">Thông tin học phí
                                <div class="ml-5 p-2"><a href="" class="  btn-link">  DANH SÁCH SINH VIÊN HOÀN THÀNH HỌC PHÍ HỌC KỲ SUMMER 2020 </a> </div>
                                <div class="ml-5 p-2"> <a href="" class="  btn-link"> THÔNG BÁO HỌC PHÍ HỌC KỲ SUMMER 2020 </a> </div>
                                <div class="ml-5 p-2"><a href="" class="  btn-link"> ĐÓNG TIỀN QUA NGÂN HÀNG KHÔNG RÕ THÔNG TIN </a> </div>
                                <div class="ml-5 p-2"><a href="" class="  btn-link">  Xem thêm ... </a> </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- hàng 3 - nhận xét GV -->
<div class="container-fluid px-lg-5 my-lg-3">
    <div class=" ">
        <div id="note-teachers" class="px-lg-5 px-3 pt-3 pb-lg-0 pb-5"></div>
    </div>
</div>

 
    <!-- Biểu đồ hình tròn điểm danh theo lớp -->
</div>
<script>
    // COMPONENT REALTIME
    let compoCountAll = $('#render-count-all');
    let compoDashBoardMonth = $('#component-dashboard-month');
    let compoDashBoardRadius = $('#dashboard-radius');
    let compoNoteTeachers = $('#note-teachers');

    let routeCountAll = '<?php echo e(route('collaboration-component-count-all')); ?>';
    let routeDashMonth = '<?php echo e(route('collaboration-component-dashboard-month')); ?>';
    let routeDashRadius = '<?php echo e(route('collaboration-component-dashboard-radius')); ?>';
    let routeNoteTeachers = '<?php echo e(route('collaboration-component-note-teachers')); ?>';

    // AJAX COUNT ALL
    $.ajax({
        type:'GET',
        url: routeCountAll,
        success:function(data) {
            compoCountAll.html(data);
        }
    });

    // AJAX DASHBOARD MONTH
    $.ajax({
        type:'GET',
        url: routeDashMonth,
        success:function(data) {
            compoDashBoardMonth.html(data);
        }
    });

    // AJAX DASHBOARD RADIUS
    $.ajax({
        type:'GET',
        url: routeDashRadius,
        success:function(data) {
            compoDashBoardRadius.html(data);
        }
    });

    // AJAX DASHBOARD RADIUS
    $.ajax({
        type:'GET',
        url: routeNoteTeachers,
        
        success:function(data) {
            compoNoteTeachers.html(data);
        }
    });

    function loadAjax(component, route){
        component.load(route);
    };

    Pusher.logToConsole = true;

    let pusher = new Pusher('32e627482335c9cb167b', {
    cluster: 'ap1'
    });

    let channel = pusher.subscribe('dashboard-home');
    channel.bind('dashboard', function(data) {
        let dataParse = JSON.parse(JSON.stringify(data));
        switch(dataParse.data.route_name){
            case routeCountAll:
                loadAjax(compoCountAll, routeCountAll);
            break;
            case routeDashMonth:
                loadAjax(compoDashBoardMonth, routeDashMonth);
            break;
            case routeNoteTeachers:
                loadAjax(compoNoteTeachers, routeNoteTeachers);
            break;
            case routeDashRadius:
                loadAjax(compoDashBoardRadius, routeDashRadius);
            break;
            default:
                console.log('not found function realtime');
        }
    
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('collaboration.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/collaboration/full-dashboard.blade.php ENDPATH**/ ?>