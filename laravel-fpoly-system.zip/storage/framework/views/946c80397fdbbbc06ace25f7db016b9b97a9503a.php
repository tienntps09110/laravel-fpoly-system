
    <div class="text-center alert-primary-neo p-2 my-3"  >Nhận xét giáo viên</div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th class="th-lg">Giáo viên</th>
                    <th class="th-lg" >Lớp</th>
                    <th class="th-lg" >Môn</th>
                    <th class="th-lg">Nhận xét</th>
                </tr>

            </thead>
            
            <tbody>
                <?php $__currentLoopData = $noteTeacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e(++$key); ?></td>
                      <td id="responsive-td1" scope="row"><?php echo e($item->teacher_full_name); ?></td>
                      <td id="responsive-td2"> <?php echo e($item->class_name); ?></td>
                      <td id="responsive-td3"><?php echo e($item->subject_name); ?></td>
                      <td id="responsive-td4"> <?php echo e($item->note); ?> </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

<?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/collaboration/component-home/note-teachers.blade.php ENDPATH**/ ?>