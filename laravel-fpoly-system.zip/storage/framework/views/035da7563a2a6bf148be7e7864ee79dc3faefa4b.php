
<?php $__env->startSection('content-student'); ?>
    <div class="container-fluid  p-4">
      <div class="box p-4">
          <div class="title p-2 mb-5 text-center alert-primary-neo">DANH SÁCH MÔN HỌC</div>
          <div class="px--lg-5 table-responsive">
              <table class=" table-center" id="datatable">
                <thead>
                  <tr>
                      <th>#</th>
                      <th>Môn học</th>
                      <th>Giảng viên</th>
                      <th >Ca học</th>
                      <th></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $classSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $classSub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($classSub->subject_name); ?></td>
                        <td><?php echo e($classSub->user_full_name); ?></td>
                        <td><?php echo e($classSub->study_time_name); ?> ( <?php echo e($classSub->study_time_start .' - ' .$classSub->study_time_end); ?> ) </td>
                        <td>
                          <a class="btn btn-link" href="<?php echo e(route('get-class-subject-detail-student', $classSub->id)); ?>">Chi tiết</a>
                        </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("student.home", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/student/get-class-subjects.blade.php ENDPATH**/ ?>