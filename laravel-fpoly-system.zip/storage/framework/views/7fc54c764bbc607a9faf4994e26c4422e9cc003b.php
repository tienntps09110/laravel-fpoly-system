<!doctype html>
<html lang="en">
  <head>
    <title>ROUTE</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        .text-center {
            text-shadow: 0 0 2px #fff;
        }
    </style>
  </head>
  <body>
      <div class="alert alert-success" role="alert">
            <h4 class="alert-heading text-center">ROUTE</h4>
            <p class="text-center">name (method): link</p>
            <p class="mb-0"></p>
          </div>
      <div class="container col-6">
          
          <div id="auth" class="alert text-center font-weight-bold">AUTH</div>
          <?php $__currentLoopData = $auth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $au): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php echo e($au['name']); ?> (<?php echo e($au['method']); ?>): <a href="<?php echo e(route($au['route'])); ?>">CLICK</a>
          <br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
          
          <div id="users" class="alert text-center font-weight-bold">USERS</div>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($ad['route'] == 'get-user'): ?>
                <?php echo e($ad['name']); ?> (<?php echo e($ad['method']); ?>): <a href="<?php echo e(route($ad['route'], '053dca80-9178-4551-b0f1-2f30a66cad92')); ?>">CLICK</a>
            <?php else: ?>
                <?php echo e($ad['name']); ?> (<?php echo e($ad['method']); ?>): <a href="<?php echo e(route($ad['route'])); ?>">CLICK</a>
            <?php endif; ?>
            <br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
          
          <div id="class" class="alert text-center font-weight-bold">CLASS</div>
          <?php $__currentLoopData = $classM; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($class['route'] == 'get-class-detail' || $class['route'] == 'update-class-view'): ?>
                <?php echo e($class['name']); ?> (<?php echo e($class['method']); ?>): <a href="<?php echo e(route($class['route'], '1')); ?>">CLICK</a>
            <?php else: ?>
                <?php echo e($class['name']); ?> (<?php echo e($class['method']); ?>): <a href="<?php echo e(route($class['route'])); ?>">CLICK</a>
            <?php endif; ?>
            <br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
          
          <div id="student" class="alert  text-center font-weight-bold">STUDENT</div>
          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($student['route'] == 'get-student' || $student['route'] == 'update-student'): ?>
                <?php echo e($student['name']); ?> (<?php echo e($student['method']); ?>): <a href="<?php echo e(route($student['route'], '76')); ?>">CLICK</a>
            <?php else: ?>
                <?php echo e($student['name']); ?> (<?php echo e($student['method']); ?>): <a href="<?php echo e(route($student['route'])); ?>">CLICK</a>
            <?php endif; ?>
            <br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
          
          <div id="subject" class="alert  text-center font-weight-bold">SUBJECT</div>
          <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($subject['route'] == 'get-subject' || $subject['route'] == 'update-subject-view'): ?>
                <?php echo e($subject['name']); ?> (<?php echo e($subject['method']); ?>): <a href="<?php echo e(route($subject['route'], '1')); ?>">CLICK</a>
            <?php else: ?>
                <?php echo e($subject['name']); ?> (<?php echo e($subject['method']); ?>): <a href="<?php echo e(route($subject['route'])); ?>">CLICK</a>
            <?php endif; ?>
            <br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
          
          <div id="classSubject" class="alert  text-center font-weight-bold">CLASS SUBJECT</div>
          <?php $__currentLoopData = $classSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($cs['route'] == 'get-class-subject' || $cs['route'] == 'update-subject-view'
              || $cs['route'] == 'get-class-subject-teacher'
              ): ?>
                <?php echo e($cs['name']); ?> (<?php echo e($cs['method']); ?>): <a href="<?php echo e(route($cs['route'], '21')); ?>">CLICK</a>
            <?php else: ?>
                <?php echo e($cs['name']); ?> (<?php echo e($cs['method']); ?>): <a href="<?php echo e(route($cs['route'])); ?>">CLICK</a>
            <?php endif; ?>
            <br>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script>
        function getRandomColor() {
            var letters = '0123456789ABCDEF';
            var color = '#';
            for (var i = 0; i < 6; i++) {
                color += letters[Math.floor(Math.random() * 16)];
            }
            return color;
        }
        $('#auth').css('background-color', getRandomColor());
        $('#users').css('background-color', getRandomColor());
        $('#class').css('background-color', getRandomColor());
        $('#student').css('background-color', getRandomColor());
        $('#subject').css('background-color', getRandomColor());
        $('#classSubject').css('background-color', getRandomColor());

    </script>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/welcome.blade.php ENDPATH**/ ?>