<div class="table-responsive">
    <table class="stripe " id="datatable" >
      <thead class="">
        <tr>
          <th scope="col">#</th>
          <th scope="col">Tên Lớp học</th>
          <th scope="col">Mã Lớp học</th>
          <th scope="col" class="row-width-200">Thời gian bắt đầu</th>
          <th scope="col" class="row-width-200">Thời gian kết thúc</th>
          <th scope="col"></th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $classMs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $classDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($classDetail->name); ?></td>
                <td><?php echo e($classDetail->code); ?></td>
                <td class="row-width-200"><?php echo e($Carbon::parse($classDetail->time_start)->toDateString()); ?></td>
                <td ><?php echo e($Carbon::parse($classDetail->time_end)->toDateString()); ?></td>
                <td><button class="btn btn-link update-class-detail"   data="<?php echo e(route('update-class-view', $classDetail->id)); ?>">Cập nhật</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
</div>

<script>
    $(document).ready(function(){
        $('.update-class-detail').each(function(){
            $(this).click(function(){
                // console.log($(this).attr('data'))
                $('#ajax-class-detail')
                .html('<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>')
                .attr('style', 'position: fixed; top: 50%; z-index: 2; left: 50%;');
                $.ajax({
                    url: $(this).attr('data'),
                    success : function(result){
                        $("#ajax-class-detail").html('').attr('style', '')
                        $("#ajax-class-detail").html(result)
                    }
                })
            })
        })
    })
</script>
<script src="<?php echo e(asset('/js/script.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/com-class.blade.php ENDPATH**/ ?>