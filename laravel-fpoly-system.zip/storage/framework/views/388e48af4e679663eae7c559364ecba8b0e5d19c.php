
<?php $__env->startSection('content-teacher'); ?>
<div class="container-fluid p-4">
    <div class="content box p-lg-5 p-3 ">
        <div class=" mb-lg-3 p-2 text-center alert-primary-neo">
            <h3>Danh sách Lớp </h3>
            <span class="">Hôm nay, ngày <?php echo e($Carbon::now()->format('d/m/Y')); ?> </span>
        </div>
        <div class="table-responsive" >
            <table class="table text-center">
                <tr> 
                    <th>#</th>
                    <th>Lớp</th>
                    <th>Môn</th>
                    <th class='row-width-300'>Ca</th>
                    <th></th>
                </tr>
                <?php $__currentLoopData = $classSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detailCs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($detailCs->class_name); ?></td>
                        <td><?php echo e($detailCs->subject_name); ?></td>
                        <td><?php echo e($detailCs->study_time_name); ?> (<?php echo e($detailCs->study_time_start .' - ' .$detailCs->study_time_end); ?>)</td>
                        <td>
                            <a class="float-right btn btn-primary-neo" 
                                href="
                                        <?php echo e(route(
                                            $detailCs->checked == 'true'?'get-attendance-class-subject-update-today': 'get-attendance-class-subject-today',[
                                                'classSubjectId'=>$detailCs->id,
                                                'dayStudyId'=>$detailCs->day_study_id
                                            ])); ?>

                                    "
                            ><?php echo e($detailCs->checked == 'true'?'Chỉnh sửa': 'Điểm danh'); ?></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </table>
        </div>
    </div>
</div>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/teacher/get-class-subjects-today.blade.php ENDPATH**/ ?>