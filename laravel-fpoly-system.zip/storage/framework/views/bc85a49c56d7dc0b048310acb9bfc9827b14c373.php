
<?php $__env->startSection('content-student'); ?>

    <div class="container-fluid  p-4">
      <div class="box p-4">
        <div class="title p-2 mb-5 alert-primary-neo text-center">Lịch học</div>
        <div class="px-lg-5 table-responsive ">
              <table class="stripe text-center" id="datatable" >
                  <thead>
                      <tr>
                          <th>#</th>
                          <th class="row-width-200">Ngày học</th>
                          <th class="row-width-200">Môn học</th>
                          <th class="row-width-300">Ca học</th>
                          <th></th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $classSubjectDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr style="<?php echo e($detail->day_checked=='true'? 'background-color: lightcyan;':''); ?>">
                              <td><?php echo e(++$key); ?></td>
                              <td> (<?php echo e($detail->day_name); ?>)  <?php echo e($detail->date); ?></td>
                              <td><?php echo e($detail->subject_name); ?></td>
                              <td ><?php echo e($detail->study_time_name); ?> (<?php echo e($detail->study_time_start); ?> - <?php echo e($detail->study_time_end); ?>)</td>
                              <td>
                                  <button class="btn btn-link" data-toggle="modal" data-target="#exampleModalCenter"> Chi tiết</button>
                              </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  

              </table>
              <!-- (Chi tiết môn học (ẩn)) -->
              <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" role="document">
                      <div class="modal-content">
                      <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLongTitle">Nội dung bài học </h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                          </button>
                      </div>
                      <div class="modal-body">
                          <p> 1. Bài Giới thiệu </p>
                          <p> 2. Bài tập về nhà </p>
                      </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/student/get-days-study.blade.php ENDPATH**/ ?>