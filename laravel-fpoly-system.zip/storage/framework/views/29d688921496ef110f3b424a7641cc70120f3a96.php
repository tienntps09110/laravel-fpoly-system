
<?php $__env->startSection('content-teacher'); ?>



<div class="container-fluid  p-4">
  <div class="box p-4">
      <div class="title p-lg-4 ">
        THÔNG TIN MÔN HỌC CỦA LỚP: <span class="font-weight-bold ml-4" id="ten-mon"><?php echo e($cLassSubject->class_name); ?> </span>
          <a id='backward' href="<?php echo e(route('get-class-subjects-teacher')); ?>"><i class="fas fa-sign-out-alt    "></i></a>
      </div>
      <div class="row pb-3">
          
          <div class="col-lg-3 col-6 p-lg-3 p-1 text-center ">Ngày bắt đầu:</div>
          <div class="col-lg-3 col-6 p-lg-3 p-1  text-center font-weight-bold"><?php echo e($Carbon::parse($cLassSubject->datetime_start)->format('d/m/Y')); ?> </div>
          <div class="col-lg-3 col-6 p-lg-3 p-1   text-center">Ngày kết thúc:</div>
          <div class="col-lg-3 col-6 p-lg-3 p-1   text-center font-weight-bold"> <?php echo e($Carbon::parse($cLassSubject->datetime_end)->format('d/m/Y')); ?>  </div>
          <div class="col-lg-3 col-6 p-lg-3 p-1   text-center">Giảng viên phụ trách:</div>
          <div class="col-lg-3 col-6 p-lg-3 p-1  text-center font-weight-bold"><?php echo e($cLassSubject->user_full_name); ?> </div>
          <div class="col-lg-3 col-6 p-lg-3 p-1   text-center">Môn học:</div>
          <div class="col-lg-3 col-6 p-lg-3 p-1   text-center font-weight-bold"> <?php echo e($cLassSubject->subject_name); ?></div> 
  
      </div>
      <div class="p-lg-4    ">
          <div class="table-responsive">
              <table class="stripe " id="datatable" >
                <thead class="">
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col" class="row-width-200">Tên Giáo Viên</th>
                    <th scope="col">Ngày Dạy</th>
                    <th scope="col">Trạng thái</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $daysClassSubject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $daysDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"> <?php echo e(++$key); ?> </td>
                            <td class="row-width-200"> <?php echo e($daysDetail->user_full_name); ?> </td>
                            <td> <?php echo e($Carbon::parse($daysDetail->date)->format('d/m/Y')); ?> </td>
                            <td class="<?php echo e($daysDetail->checked =="false" ? "text-danger" :"text-success"); ?>" > <?php echo e($daysDetail->checked =="false" ? "Chưa Dạy" :"Đã dạy"); ?> </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                  
                </tbody>
              </table>
            </div>
      </div>
  </div>
</div>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('teacher.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/teacher/get-detail-class-subject.blade.php ENDPATH**/ ?>