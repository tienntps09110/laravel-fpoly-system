
<nav id="sidebar" >
  <div class="fixed-sidebar">
    <div class="sidebar-header">
      <div class="rounded-circle">
        <img src="<?php echo e(Auth::user()->avatar_img_path); ?>" alt="<?php echo e(Auth::user()->avatar_img_path); ?>" width="100%" >
      </div>
 </div>

 <ul class="list-unstyled components">
     <li class="text-center">
       <span class="small" style="display:block">Giảng viên:</span>
        <?php echo e(Auth::user()->full_name); ?>

     </li>
     <li class="date-teach">
       <a href="<?php echo e(route('get-class-subject-teacher-today')); ?>"> <i class="fas fa-edit    "></i> Điểm danh</a>
     </li>
     <li class="date-teach">
       <a href="<?php echo e(route('get-class-subjects-teacher')); ?>"> <i class="fas fa-list    "></i> Danh sách lớp dạy</a>
     </li>
     <li class="date-teach">
       <a  > <i class="fas fa-envelope    "></i> Hộp thư</a>
     </li>
     
 </ul>
 <ul class="list-unstyled CTAs">
   <li>
     <form action="<?php echo e(route('logout')); ?>" method="post">
         <?php echo csrf_field(); ?>
         <button type="submit" class="btn btn-link logout"> <i class="fas fa-sign-out-alt"></i> Đăng xuất  </button> 
     </form>
   </li>
 </ul>
  </div>
        </nav>

        

        <?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/teacher/sidebar.blade.php ENDPATH**/ ?>