
<nav id="sidebar">
	<div class="fixed-sidebar">
		<div class="sidebar-header">

			<div class="rounded-circle">
				<img src="<?php echo e(Auth::user()->avatar_img_path); ?>" alt="<?php echo e(Auth::user()->avatar_img_path); ?>" width="100%" >
			</div>       
		</div>

		<ul class="list-unstyled components">
			<p class="text-center" style="background-color: #1EBD9E;"><?php echo e(Auth::user()->full_name); ?></p>
			<li>
				<a href="<?php echo e(route('collaboration-home')); ?>">Trang chủ <span style="float: left;"><i class="fas fa-user-plus"></i></span>
				</a>
			</li>
			<li>
				<a href="<?php echo e(route('search-student-view')); ?>">Tra cứu sinh viên <span style="float: left;"><i class="fas fa-divide"></i></span>
				</a>
			</li>
		 
		</ul>

		<ul class="list-unstyled CTAs">
			<li>
				<form action="<?php echo e(route('logout')); ?>" method="post">
					<?php echo csrf_field(); ?>
					<button type="submit" class="btn btn-link logout"> <i class="fas fa-sign-out-alt"></i> Đăng xuất  </button> 
				</form>
			</li>
		</ul>
	</div>
</nav>
 <?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/collaboration/sidebar.blade.php ENDPATH**/ ?>