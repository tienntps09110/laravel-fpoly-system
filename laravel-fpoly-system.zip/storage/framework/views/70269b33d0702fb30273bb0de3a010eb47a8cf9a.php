
<?php echo e($user); ?>

<hr>
LINK UPDATE <a href="<?php echo e(route('update-user-view', $user->uuid)); ?>">CLICK</a><?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/department/user.blade.php ENDPATH**/ ?>