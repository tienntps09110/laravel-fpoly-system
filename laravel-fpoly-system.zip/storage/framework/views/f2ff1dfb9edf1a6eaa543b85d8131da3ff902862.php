<!doctype html>
<html lang="en">
  <head>
    <title>Trang giảng viên</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base href="<?php echo e(asset('')); ?>">
    <link rel="shortcut icon" href="laravel-icon.svg" type="image/svg">

    <!-- Bootstrap CSS -->
     
    <link rel="stylesheet" href="css/bootstrap.min.css" >
    <script defer src="js/solid.min.js" ></script>
    <script defer src="js/fontawesome.min.js" ></script>  
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/neo-style.css">
    <link rel="stylesheet" href="css/datatable-neo.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="css/loading-tien.css">
    <script src="js/jquery-3.5.1.js"></script>
</head>
  <body>
      <div class="wrapper">
          <!-- sidebar -->
          <?php echo $__env->make('teacher.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         
          <div id="content">
            <!-- navbar -->
              <?php echo $__env->make('teacher.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- content -->
              <?php echo $__env->yieldContent('content-teacher'); ?>
          </div>
      </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.js"></script>
    <script type="text/javascript" charset="utf8" src="js/jquery.dataTables.min.js"></script>
    <script src="js/script.js" ></script>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-fpoly-system\resources\views/teacher/home.blade.php ENDPATH**/ ?>