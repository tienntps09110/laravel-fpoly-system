<?php

use Illuminate\Support\Facades\Route;

Route::get('home', 'Admin\Get@home')->name('admin-home');