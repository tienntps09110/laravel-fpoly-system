<?php

use Illuminate\Support\Facades\Route;

Route::get('home', 'Teacher\Get@home')->name('teacher-home');