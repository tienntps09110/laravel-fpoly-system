<?php

use Illuminate\Support\Facades\Route;

Route::get('home', 'Department\Get@home')->name('department-home');