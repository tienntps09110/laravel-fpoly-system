<?php

use Illuminate\Support\Facades\Route;


// Route::get('create-attendances', 'DaysClassSubject\Create@attent')->name('create-class-subject-view');
