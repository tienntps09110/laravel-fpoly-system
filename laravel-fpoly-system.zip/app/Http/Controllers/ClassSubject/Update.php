<?php

namespace App\Http\Controllers\ClassSubject;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Update extends Controller
{
    public function classSubject(){
        
    }
}
