<?php

namespace App\Http\Controllers\DaysClassSubject;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Create extends Controller
{
    //
}
