{{-- DETAIL USER --}}
{{ $user }}
<hr>
LINK UPDATE <a href="{{ route('update-user-view', $user->uuid) }}">CLICK</a>