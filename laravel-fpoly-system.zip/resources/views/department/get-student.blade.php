DETAIL STUDENTS

{{ $student }}