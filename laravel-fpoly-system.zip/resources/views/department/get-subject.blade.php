GET DETAIL SUBJECT

{{ $subject }}