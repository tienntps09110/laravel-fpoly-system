DETAIL CLASS
<br>
<hr>
{{ $class }}