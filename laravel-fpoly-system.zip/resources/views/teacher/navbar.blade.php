<nav class="navbar navbar-expand-lg navbar-light bg-light navbar-bg" style="padding:0rem">
              <div class="container-fluid">
                    <div class="col-lg-5"  > 
                        <div class="title-navbar">
                                Trang Giảng Viên 
                        </div> 
                        </div>
                    <div class="col-lg-4">
                        <form class="form-inline form-search">
                            <div class="col-12">
                                <input id="input-search" class="input-search " type="search" placeholder="Tìm kiếm..." aria-label="Search">
                            </div>
                            <label for="input-search" class="icone"> <i class="fas fa-search"></i></label>
                        </form>
                    </div>
                    <div class="d-flex justify-content-center col-lg-3" id="navbar-icon">
                        <a class="nav-link "style="color:#FFFFFF"  ><i class="fas fa-bell"></i></a>
                        <a class="nav-link" style="color:#FFFFFF"  ><i class="fas fa-envelope"></i></a>
                        <a class="nav-link" id="btn-menu" ><i class="fas fa-bars"></i></a>
                    </div>
                  </button>
              </div>
             
            </nav>